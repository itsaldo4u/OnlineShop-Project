import AboutForm from "../componentes/about/AboutForm"; 

const AboutPage = () => {
  return (
    <div>
      <AboutForm />
    </div>
  );
};

export default AboutPage;
