import { Outlet, useLocation } from "react-router-dom";
import Navbar from "../componentes/navbar/Navbar";
import Footer from "../componentes/footer/Footer";
import WelcomeForm from "../componentes/welcome/WelcomeForm";

export default function DefaultPage() {
  const location = useLocation();
  const path = location.pathname;

  // Mos shfaq layout për faqet login/signup
  const hideLayout = path === "/login" || path === "/signup";

  return (
    <>
      {!hideLayout && <Navbar />}
      {!hideLayout && path === "/" && <WelcomeForm />}
      <Outlet />
      {!hideLayout && <Footer />}
    </>
  );
}
