import { Link } from "react-router-dom";

const Signup: React.FC = () => {
  return (
    <div style={{ padding: "2rem", maxWidth: "400px", margin: "0 auto" }}>
      <h2>Regjistrohu</h2>
      <form>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Emri</label>
          <input type="text" className="form-control" id="name" required />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input type="email" className="form-control" id="email" required />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Fjalëkalimi</label>
          <input type="password" className="form-control" id="password" required />
        </div>
        <button type="submit" className="btn btn-success">Krijo Llogari</button>
      </form>
      <p className="mt-3">
        Ke një llogari? <Link to="/login">Hyr</Link>
      </p>
    </div>
  );
};

export default Signup;
