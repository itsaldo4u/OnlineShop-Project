import KontaktForm from "../componentes/kontakt/KontaktForm";

const AboutPage = () => {
  return (
    <div>
      <KontaktForm />
    </div>
  );
};

export default AboutPage;
